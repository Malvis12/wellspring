<?php

session_start(); // <-- Add this at the very top

header('Content-Type: application/json');
require_once __DIR__ . '/db.php';

// Helper: sanitize input
function clean($str) {
    global $conn;
    return htmlspecialchars(trim($conn->real_escape_string($str)));
}

// Helper: send JSON and exit
function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'signup') {
        $fullName = clean($_POST['fullName'] ?? '');
        $businessName = clean($_POST['businessName'] ?? '');
        $email = clean($_POST['email'] ?? '');
        $phone = clean($_POST['phone'] ?? '');
        $password = $_POST['password'] ?? '';

        // Validation
        if (!$fullName || !$businessName || !$email || !$phone || !$password) {
            respond(['status' => 'error', 'message' => 'All fields are required.'], 400);
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            respond(['status' => 'error', 'message' => 'Invalid email address.'], 400);
        }
        if (!preg_match('/^\+?\d{7,15}$/', $phone)) {
            respond(['status' => 'error', 'message' => 'Invalid phone number.'], 400);
        }
        if (strlen($password) < 6) {
            respond(['status' => 'error', 'message' => 'Password must be at least 6 characters.'], 400);
        }

        // Check for duplicate email or phone
        $stmt = $conn->prepare("SELECT id FROM sellers WHERE email=? OR phone=? LIMIT 1");
        $stmt->bind_param("ss", $email, $phone);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            respond(['status' => 'error', 'message' => 'Email or phone already registered.'], 409);
        }
        $stmt->close();

        // Hash password
        $hashed = password_hash($password, PASSWORD_DEFAULT);

        // Insert into DB
        $stmt = $conn->prepare("INSERT INTO sellers (full_name, business_name, email, phone, password) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $fullName, $businessName, $email, $phone, $hashed);
        if ($stmt->execute()) {
            respond(['status' => 'success', 'message' => 'Account created successfully.']);
        } else {
            respond(['status' => 'error', 'message' => 'Database error.'], 500);
        }
    }

    if ($action === 'login') {
        $identifier = clean($_POST['identifier'] ?? '');
        $password = $_POST['password'] ?? '';

        if (!$identifier || !$password) {
            respond(['status' => 'error', 'message' => 'All fields are required.'], 400);
        }

        // Find user by email or phone
        $stmt = $conn->prepare("SELECT id, password FROM sellers WHERE email=? OR phone=? LIMIT 1");
        $stmt->bind_param("ss", $identifier, $identifier);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows === 0) {
            respond(['status' => 'error', 'message' => 'Account not found.'], 404);
        }
        $stmt->bind_result($id, $hashed);
        $stmt->fetch();

        if (!password_verify($password, $hashed)) {
            respond(['status' => 'error', 'message' => 'Incorrect password.'], 401);
        }

        // Set session for logged in seller
        $_SESSION['seller_id'] = $id;

        respond(['status' => 'success', 'message' => 'Logged in successfully.']);
    }
}

respond(['status' => 'error', 'message' => 'Invalid request.'], 405);