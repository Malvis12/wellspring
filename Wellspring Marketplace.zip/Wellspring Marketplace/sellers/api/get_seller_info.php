<?php
// filepath: c:\xampp\htdocs\Wellspring Marketplace\sellers\api\get_seller_info.php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/db.php';

if (!isset($_SESSION['seller_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not authenticated']);
    exit;
}
$seller_id = $_SESSION['seller_id'];

$stmt = $conn->prepare("SELECT full_name, business_name, email, phone FROM sellers WHERE id = ?");
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$stmt->bind_result($full_name, $business_name, $email, $phone);
if ($stmt->fetch()) {
    echo json_encode([
        'status' => 'success',
        'full_name' => $full_name,
        'business_name' => $business_name,
        'email' => $email,
        'phone' => $phone
    ]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Seller not found']);
}
$stmt->close();