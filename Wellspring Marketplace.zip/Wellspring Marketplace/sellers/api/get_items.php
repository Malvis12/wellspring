<?php
// filepath: c:\xampp\htdocs\Wellspring Marketplace\sellers\api\get_items.php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/db.php';

// Check if seller is logged in
if (!isset($_SESSION['seller_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not authenticated']);
    exit;
}
$seller_id = $_SESSION['seller_id'];

// Fetch items for this seller
$stmt = $conn->prepare("SELECT id, item_name, category, price, item_condition, availability, description, images, created_at FROM items WHERE seller_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $seller_id);
$stmt->execute();
$result = $stmt->get_result();

$items = [];
while ($row = $result->fetch_assoc()) {
    $row['images'] = json_decode($row['images'], true) ?: [];
    $items[] = $row;
}

echo json_encode(['status' => 'success', 'items' => $items]);