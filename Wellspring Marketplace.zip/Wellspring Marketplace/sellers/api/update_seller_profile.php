<?php
// filepath: c:\xampp\htdocs\Wellspring Marketplace\sellers\api\update_seller_profile.php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/db.php';

if (!isset($_SESSION['seller_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not authenticated']);
    exit;
}
$seller_id = $_SESSION['seller_id'];

$full_name = trim($_POST['full_name'] ?? '');
$business_name = trim($_POST['business_name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');

if (!$full_name || !$business_name || !$email || !$phone) {
    echo json_encode(['status' => 'error', 'message' => 'All fields are required.']);
    exit;
}

$stmt = $conn->prepare("UPDATE sellers SET full_name=?, business_name=?, email=?, phone=? WHERE id=?");
$stmt->bind_param("ssssi", $full_name, $business_name, $email, $phone, $seller_id);
if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Profile updated successfully.']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to update profile.']);
}
$stmt->close();