<?php
// filepath: c:\xampp\htdocs\Wellspring Marketplace\sellers\api\edit_item.php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/db.php';

if (!isset($_SESSION['seller_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not authenticated']);
    exit;
}
$seller_id = $_SESSION['seller_id'];

$id = intval($_POST['id'] ?? 0);
$fields = ['itemName', 'category', 'price', 'condition', 'availability'];
foreach ($fields as $field) {
    if (empty($_POST[$field])) {
        echo json_encode(['status' => 'error', 'message' => "Missing field: $field"]);
        exit;
    }
}
$item_name = trim($_POST['itemName']);
$category = trim($_POST['category']);
$price = floatval($_POST['price']);
$item_condition = trim($_POST['condition']);
$availability = trim($_POST['availability']);
$description = trim($_POST['description'] ?? '');

$image_names = [];
if (!empty($_FILES['images']['name'][0])) {
    $upload_dir = __DIR__ . '/../../uploads/';
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);

    foreach ($_FILES['images']['name'] as $idx => $name) {
        $tmp_name = $_FILES['images']['tmp_name'][$idx];
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        if (!in_array($ext, $allowed)) continue;
        $new_name = uniqid('img_', true) . '.' . $ext;
        if (move_uploaded_file($tmp_name, $upload_dir . $new_name)) {
            $image_names[] = $new_name;
        }
    }
    $images_json = json_encode($image_names);
    $stmt = $conn->prepare("UPDATE items SET item_name=?, category=?, price=?, item_condition=?, availability=?, description=?, images=? WHERE id=? AND seller_id=?");
    $stmt->bind_param("ssdssssii", $item_name, $category, $price, $item_condition, $availability, $description, $images_json, $id, $seller_id);
} else {
    $stmt = $conn->prepare("UPDATE items SET item_name=?, category=?, price=?, item_condition=?, availability=?, description=? WHERE id=? AND seller_id=?");
    $stmt->bind_param("ssdsssii", $item_name, $category, $price, $item_condition, $availability, $description, $id, $seller_id);
}

if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Item updated']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Update failed']);
}