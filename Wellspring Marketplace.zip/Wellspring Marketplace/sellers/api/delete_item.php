<?php
// filepath: c:\xampp\htdocs\Wellspring Marketplace\sellers\api\delete_item.php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/db.php';

if (!isset($_SESSION['seller_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not authenticated']);
    exit;
}
$seller_id = $_SESSION['seller_id'];

$id = intval($_POST['id'] ?? 0);
if (!$id) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid item']);
    exit;
}

// Optional: Remove images from disk
$stmt = $conn->prepare("SELECT images FROM items WHERE id=? AND seller_id=?");
$stmt->bind_param("ii", $id, $seller_id);
$stmt->execute();
$stmt->bind_result($images_json);
if ($stmt->fetch() && $images_json) {
    $images = json_decode($images_json, true);
    foreach ($images as $img) {
        $file = __DIR__ . '/../../uploads/' . $img;
        if (is_file($file)) @unlink($file);
    }
}
$stmt->close();

// Delete item
$stmt = $conn->prepare("DELETE FROM items WHERE id=? AND seller_id=?");
$stmt->bind_param("ii", $id, $seller_id);
if ($stmt->execute()) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Delete failed']);
}