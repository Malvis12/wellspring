<?php
// filepath: c:\xampp\htdocs\Wellspring Marketplace\admin\api\admin_user_growth.php
session_start();
header('Content-Type: application/json');
require_once '../../api/db.php';
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['status' => 'error']);
    exit;
}
$data = [];
$res = $conn->query("SELECT DATE_FORMAT(created_at, '%b') as month, COUNT(*) as count FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH) GROUP BY month ORDER BY MIN(created_at)");
while ($row = $res->fetch_assoc()) {
    $data[] = $row;
}
echo json_encode(['status' => 'success', 'growth' => $data]);