<?php
session_start();
header('Content-Type: application/json');
require_once '../../api/db.php';

if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
$offset = ($page - 1) * $limit;

// Get total count
$total_res = $conn->query("SELECT COUNT(*) FROM users");
$total = $total_res->fetch_row()[0];

$users = [];
$stmt = $conn->prepare("SELECT id, first_name, last_name, email, created_at FROM users ORDER BY created_at DESC LIMIT ? OFFSET ?");
$stmt->bind_param("ii", $limit, $offset);
$stmt->execute();
$res = $stmt->get_result();

while ($row = $res->fetch_assoc()) {
    $users[] = $row;
}

echo json_encode([
    'status' => 'success',
    'users' => $users,
    'pagination' => [
        'page' => $page,
        'limit' => $limit,
        'total' => (int)$total
    ]
]);