<?php
// filepath: c:\xampp\htdocs\Wellspring Marketplace\admin\api\admin_dashboard_stats.php
session_start();
header('Content-Type: application/json');
require_once '../../api/db.php';
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['status' => 'error']);
    exit;
}
$total_users = $conn->query("SELECT COUNT(*) FROM users")->fetch_row()[0];
$total_sellers = $conn->query("SELECT COUNT(*) FROM sellers")->fetch_row()[0];
$active_listings = $conn->query("SELECT COUNT(*) FROM items")->fetch_row()[0];
$total_requests = $conn->query("SELECT COUNT(*) FROM requests")->fetch_row()[0];
echo json_encode([
    'status' => 'success',
    'total_users' => $total_users,
    'total_sellers' => $total_sellers,
    'active_listings' => $active_listings,
    'total_requests' => $total_requests
]);