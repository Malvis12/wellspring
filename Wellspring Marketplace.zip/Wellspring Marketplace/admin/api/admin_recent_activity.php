<?php
// filepath: c:\xampp\htdocs\Wellspring Marketplace\admin\api\admin_recent_activity.php
session_start();
header('Content-Type: application/json');
require_once '../../api/db.php';
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['status' => 'error']);
    exit;
}
$activities = [];
// Example: fetch last 10 user registrations
$res = $conn->query("SELECT CONCAT(first_name, ' ', last_name) as name, created_at FROM users ORDER BY created_at DESC LIMIT 10");
while ($row = $res->fetch_assoc()) {
    $activities[] = [
        'title' => 'New user registered',
        'detail' => $row['name'] . ' joined the platform',
        'time_ago' => time_elapsed_string($row['created_at'])
    ];
}
// You can add more activity types here...
echo json_encode(['status' => 'success', 'activities' => $activities]);

// Helper function
function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);
    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;
    $string = [
        'y' => 'y',
        'm' => 'mo',
        'w' => 'w',
        'd' => 'd',
        'h' => 'h',
        'i' => 'm',
        's' => 's',
    ];
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . $v;
        } else {
            unset($string[$k]);
        }
    }
    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}