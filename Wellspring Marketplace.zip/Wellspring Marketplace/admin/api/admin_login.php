<?php
// filepath: c:\xampp\htdocs\Wellspring Marketplace\admin\api\admin_login.php
session_start();
header('Content-Type: application/json');
require_once '../../api/db.php';

$data = json_decode(file_get_contents('php://input'), true);
$username = trim($data['username'] ?? '');
$password = $data['password'] ?? '';

$stmt = $conn->prepare("SELECT id, password FROM admin WHERE username = ?");
$stmt->bind_param("s", $username);
$stmt->execute();
$stmt->bind_result($id, $hash);
if ($stmt->fetch() && password_verify($password, $hash)) {
    $_SESSION['admin_id'] = $id;
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid username or password']);
}
$stmt->close();
$conn->close();