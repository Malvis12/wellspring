<?php
// filepath: c:\xampp\htdocs\Wellspring Marketplace\admin\api\check_admin_session.php
session_start();
header('Content-Type: application/json');
if (isset($_SESSION['admin_id'])) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error']);
}