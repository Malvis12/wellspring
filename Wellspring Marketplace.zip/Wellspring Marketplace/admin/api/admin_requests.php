<?php
session_start();
header('Content-Type: application/json');
require_once '../../api/db.php';
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['status' => 'error']);
    exit;
}
$requests = [];
$res = $conn->query("SELECT r.id, r.item_name, r.category, r.budget_min, r.budget_max, r.urgency, r.description, r.created_at, u.first_name, u.last_name FROM requests r LEFT JOIN users u ON r.user_id = u.id ORDER BY r.created_at DESC");
while ($row = $res->fetch_assoc()) {
    $requests[] = $row;
}
echo json_encode(['status' => 'success', 'requests' => $requests]);