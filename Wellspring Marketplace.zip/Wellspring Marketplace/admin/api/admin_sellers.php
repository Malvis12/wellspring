<?php
session_start();
header('Content-Type: application/json');
require_once '../../api/db.php';
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['status' => 'error']);
    exit;
}
$sellers = [];
$res = $conn->query("SELECT id, business_name, email, phone, created_at FROM sellers ORDER BY created_at DESC");
while ($row = $res->fetch_assoc()) {
    $sellers[] = $row;
}
echo json_encode(['status' => 'success', 'sellers' => $sellers]);