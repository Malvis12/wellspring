<?php
session_start();
header('Content-Type: application/json');
require_once '../../api/db.php';
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['status' => 'error']);
    exit;
}
$listings = [];
$res = $conn->query("SELECT i.id, i.item_name AS title, i.category, i.price, i.status, i.created_at, s.business_name FROM items i LEFT JOIN sellers s ON i.seller_id = s.id ORDER BY i.created_at DESC");
while ($row = $res->fetch_assoc()) {
    $listings[] = $row;
}
echo json_encode(['status' => 'success', 'listings' => $listings]);