<?php
// filepath: c:\xampp\htdocs\Wellspring Marketplace\admin\api\admin_category_distribution.php
session_start();
header('Content-Type: application/json');
require_once '../../api/db.php';
if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['status' => 'error']);
    exit;
}
$categories = [];
$res = $conn->query("SELECT category, COUNT(*) as value FROM items GROUP BY category");
while ($row = $res->fetch_assoc()) {
    $categories[] = [
        'name' => $row['category'],
        'value' => (int)$row['value']
    ];
}
echo json_encode(['status' => 'success', 'categories' => $categories]);