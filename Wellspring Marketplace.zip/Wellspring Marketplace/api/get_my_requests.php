<?php
// filepath: c:\xampp\htdocs\Wellspring Marketplace\api\get_my_requests.php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not authenticated']);
    exit;
}
$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT id, item_name, category, budget_min, budget_max, urgency, description, created_at FROM requests WHERE user_id = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

$requests = [];
while ($row = $result->fetch_assoc()) {
    $requests[] = $row;
}
echo json_encode(['status' => 'success', 'requests' => $requests]);