<?php
// filepath: c:\xampp\htdocs\Wellspring Marketplace\sellers\api\get_featured_items.php
header('Content-Type: application/json');
require_once __DIR__ . '/db.php';

// Fetch all items with seller info (business_name, phone)
$sql = "SELECT items.*, sellers.business_name, sellers.phone 
        FROM items 
        JOIN sellers ON items.seller_id = sellers.id 
        WHERE items.availability = 'Available'
        ORDER BY items.created_at DESC
        LIMIT 12";
$result = $conn->query($sql);

$items = [];
while ($row = $result->fetch_assoc()) {
    $row['images'] = json_decode($row['images'], true) ?: [];
    $items[] = $row;
}
echo json_encode(['status' => 'success', 'items' => $items]);