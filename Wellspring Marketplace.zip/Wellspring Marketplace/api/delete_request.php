<?php
// filepath: c:\xampp\htdocs\Wellspring Marketplace\api\delete_request.php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not authenticated']);
    exit;
}
$user_id = $_SESSION['user_id'];
$data = json_decode(file_get_contents('php://input'), true);
$id = intval($data['id'] ?? 0);

$stmt = $conn->prepare("DELETE FROM requests WHERE id=? AND user_id=?");
$stmt->bind_param("ii", $id, $user_id);
if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Request deleted successfully.']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to delete request.']);
}