<?php
// filepath: c:\xampp\htdocs\Wellspring Marketplace\api\login.php
session_start(); // <-- Add this line
header('Content-Type: application/json');
require_once 'db.php';

$data = json_decode(file_get_contents('php://input'), true);
$identifier = $conn->real_escape_string($data['identifier']);
$password = $data['password'];

$query = "SELECT * FROM users WHERE email='$identifier' OR phone='$identifier' LIMIT 1";
$result = $conn->query($query);
if ($user = $result->fetch_assoc()) {
    if (password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id']; // <-- Set the session here
        echo json_encode([
            'message' => 'Login successful',
            'lastName' => $user['last_name']
        ]);
    } else {
        http_response_code(401);
        echo json_encode(['message' => 'Invalid credentials']);
    }
} else {
    http_response_code(401);
    echo json_encode(['message' => 'Invalid credentials']);
}
$conn->close();
?>