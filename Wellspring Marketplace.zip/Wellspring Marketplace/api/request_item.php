<?php
// filepath: c:\xampp\htdocs\Wellspring Marketplace\api\request_item.php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not authenticated']);
    exit;
}
$user_id = $_SESSION['user_id'];

// Get user's phone number from users table
$stmt = $conn->prepare("SELECT phone FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($user_phone);
if (!$stmt->fetch()) {
    echo json_encode(['status' => 'error', 'message' => 'User not found']);
    exit;
}
$stmt->close();

// Validate fields
$item_name = trim($_POST['item_name'] ?? '');
$category = trim($_POST['category'] ?? '');
$budget_min = $_POST['budget_min'] ?? null;
$budget_max = $_POST['budget_max'] ?? null;
$urgency = trim($_POST['urgency'] ?? '');
$description = trim($_POST['description'] ?? '');

if (!$item_name || !$category || !$description) {
    echo json_encode(['status' => 'error', 'message' => 'Missing required fields']);
    exit;
}

// Insert request
$stmt = $conn->prepare("INSERT INTO requests (user_id, item_name, category, budget_min, budget_max, urgency, description, user_phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("issddsss", $user_id, $item_name, $category, $budget_min, $budget_max, $urgency, $description, $user_phone);
if ($stmt->execute()) {
    $request_id = $stmt->insert_id;

    // Notify all sellers with user info
    $sellers = $conn->query("SELECT id FROM sellers");
    $notif_message = "New item request: $item_name (Category: $category, Budget: $budget_min-$budget_max, Urgency: $urgency). Description: $description. User phone: $user_phone";
    while ($row = $sellers->fetch_assoc()) {
        $seller_id = $row['id'];
        $stmtNotif = $conn->prepare("INSERT INTO notifications (seller_id, request_id, message) VALUES (?, ?, ?)");
        $stmtNotif->bind_param("iis", $seller_id, $request_id, $notif_message);
        $stmtNotif->execute();
        $stmtNotif->close();
    }

    echo json_encode(['status' => 'success', 'message' => 'Request posted and all sellers notified']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Database error']);
}