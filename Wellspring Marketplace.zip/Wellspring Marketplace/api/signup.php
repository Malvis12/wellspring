<?php
header('Content-Type: application/json');
require_once 'db.php';

$data = json_decode(file_get_contents('php://input'), true);
$firstName = $conn->real_escape_string($data['firstName']);
$lastName = $conn->real_escape_string($data['lastName']);
$email = $conn->real_escape_string($data['email']);
$phone = $conn->real_escape_string($data['phone']);
$password = password_hash($data['password'], PASSWORD_DEFAULT);

$query = "INSERT INTO users (first_name, last_name, email, phone, password) VALUES ('$firstName', '$lastName', '$email', '$phone', '$password')";
if ($conn->query($query)) {
    echo json_encode(['message' => 'Signup successful']);
} else {
    http_response_code(400);
    echo json_encode(['message' => 'Email or phone already exists']);
}
$conn->close();
?>