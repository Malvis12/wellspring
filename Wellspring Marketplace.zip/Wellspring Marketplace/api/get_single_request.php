<?php
// filepath: c:\xampp\htdocs\Wellspring Marketplace\api\get_single_request.php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not authenticated']);
    exit;
}
$user_id = $_SESSION['user_id'];
$id = intval($_GET['id'] ?? 0);

$stmt = $conn->prepare("SELECT id, item_name, category, budget_min, budget_max, urgency, description FROM requests WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    echo json_encode(['status' => 'success', 'request' => $row]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Request not found']);
}