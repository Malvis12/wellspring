<?php
// filepath: c:\xampp\htdocs\Wellspring Marketplace\api\update_request.php
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not authenticated']);
    exit;
}
$user_id = $_SESSION['user_id'];
$id = intval($_POST['id'] ?? 0);

$item_name = trim($_POST['item_name'] ?? '');
$category = trim($_POST['category'] ?? '');
$budget_min = $_POST['budget_min'] ?? null;
$budget_max = $_POST['budget_max'] ?? null;
$urgency = trim($_POST['urgency'] ?? '');
$description = trim($_POST['description'] ?? '');

if (!$item_name || !$category || !$description) {
    echo json_encode(['status' => 'error', 'message' => 'Please fill all required fields.']);
    exit;
}

$stmt = $conn->prepare("UPDATE requests SET item_name=?, category=?, budget_min=?, budget_max=?, urgency=?, description=? WHERE id=? AND user_id=?");
$stmt->bind_param("ssddssii", $item_name, $category, $budget_min, $budget_max, $urgency, $description, $id, $user_id);
if ($stmt->execute()) {
    echo json_encode(['status' => 'success', 'message' => 'Request updated successfully.']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to update request.']);
}